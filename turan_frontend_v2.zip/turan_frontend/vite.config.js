import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Vite configuration for the Turan frontend.
// The `base` option ensures that assets and routes resolve correctly when
// the site is hosted from a subpath such as /Turan/ on GitHub Pages.
export default defineConfig({
  plugins: [react()],
  base: '/Turan/'
});