import React from 'react';

/**
 * A simple navigation bar for the Digital Turan site. It uses anchor tags
 * because the prototype does not include a client‑side router. Clicking
 * these links will reload the page and display the appropriate content.
 */
export default function Navbar() {
  return (
    <nav style={{
      padding: '12px 20px',
      borderBottom: '1px solid #e5e7eb',
      background: '#f7f7f7',
      display: 'flex',
      gap: '1rem',
    }}>
      <a href="/Turan/">Главная</a>
      <a href="/Turan/worlds">Миры</a>
      <a href="/Turan/stats">Статистика</a>
      <a href="/Turan/profile">Профиль</a>
    </nav>
  );
}