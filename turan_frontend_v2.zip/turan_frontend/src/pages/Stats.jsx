import React, { useEffect, useState } from 'react';
import { api } from '../utils/api.js';

/**
 * The Stats page fetches and displays aggregated statistics from the
 * backend. In this prototype we simply render the JSON object. You can
 * extend this component to include charts and graphs using a charting
 * library (e.g., Chart.js or Recharts) once you add those dependencies.
 */
export default function Stats() {
  const [stats, setStats] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    api.get('/stats')
      .then(data => setStats(data))
      .catch(err => setError(err.message));
  }, []);

  return (
    <div style={{ padding: '20px' }}>
      <h1>Статистика</h1>
      {error && (
        <p style={{ color: 'red' }}>Ошибка загрузки статистики: {error}</p>
      )}
      {stats ? (
        <pre>{JSON.stringify(stats, null, 2)}</pre>
      ) : (
        <p>Загрузка...</p>
      )}
    </div>
  );
}