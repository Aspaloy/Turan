import React, { useEffect, useState } from 'react';
import { api } from '../utils/api.js';

/**
 * The Worlds page shows a list of available cultural worlds on the
 * platform. In this prototype we fetch a list from the backend
 * (/worlds endpoint) and display it. Each world could link to its own
 * detailed page in a future version.
 */
export default function Worlds() {
  const [worlds, setWorlds] = useState([]);
  const [error, setError] = useState(null);

  useEffect(() => {
    // Fetch list of worlds from the backend. If the request fails
    // gracefully handle the error and show a fallback message.
    api.get('/worlds')
      .then(data => setWorlds(data.worlds))
      .catch(err => setError(err.message));
  }, []);

  return (
    <div style={{ padding: '20px' }}>
      <h1>Миры народов</h1>
      {error && (
        <p style={{ color: 'red' }}>Ошибка загрузки данных: {error}</p>
      )}
      <ul style={{ listStyleType: 'none', padding: 0 }}>
        {worlds.map(world => (
          <li key={world} style={{
            padding: '0.5rem 0',
            borderBottom: '1px solid #e5e7eb',
          }}>
            {world}
          </li>
        ))}
      </ul>
    </div>
  );
}