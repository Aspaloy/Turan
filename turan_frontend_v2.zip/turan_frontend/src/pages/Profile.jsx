import React from 'react';

/**
 * The Profile page displays user information, achievements and roles.
 * In this prototype we show static data. In a real application you would
 * fetch the current user's profile from the backend and allow editing.
 */
export default function Profile() {
  // Example static profile data. Replace with data from your backend.
  const user = {
    name: 'Айдан',
    role: 'Разработчик',
    rating: 1234,
    achievements: [
      { id: 1, title: 'Участник конкурса AI Hackathon' },
      { id: 2, title: 'Победитель квеста "Изучение языка"' },
    ],
  };

  return (
    <div style={{ padding: '20px' }}>
      <h1>Профиль</h1>
      <p><strong>Имя:</strong> {user.name}</p>
      <p><strong>Роль:</strong> {user.role}</p>
      <p><strong>Рейтинг:</strong> {user.rating}</p>
      <h2>Достижения</h2>
      <ul>
        {user.achievements.map(item => (
          <li key={item.id}>{item.title}</li>
        ))}
      </ul>
    </div>
  );
}