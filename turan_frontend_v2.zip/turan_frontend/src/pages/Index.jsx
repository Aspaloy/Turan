import React from 'react';

/**
 * The home page for the Digital Turan platform. This page introduces the
 * project, highlights key features such as cultural worlds, rankings and
 * gamification, and displays a simple recommended content section. In
 * production you could replace the static feed with dynamic data from
 * the backend.
 */
export default function Index() {
  // Example static feed content. In the future you could fetch this from
  // an API and allow users to interact (like, comment, etc.).
  const feedItems = [
    {
      id: 1,
      title: 'Исследование кыргызского эпоса Манас',
      description: 'Узнайте больше об эпосе Манас и его значении для кыргызского народа.',
    },
    {
      id: 2,
      title: 'Разработка мобильного приложения для изучения тюркских языков',
      description: 'Команда из Узбекского мира делится опытом создания учебного приложения.',
    },
    {
      id: 3,
      title: 'Истории успеха: молодые художники из Турецкого мира',
      description: 'Как творческие молодые люди превращают свои проекты в успешные стартапы.',
    },
  ];
  return (
    <div style={{ padding: '20px' }}>
      <section style={{ marginBottom: '2rem' }}>
        <h1>Цифровой Туран</h1>
        <p>
          Добро пожаловать на платформу для сотрудничества и развития культур
          тюркских народов. Создавайте проекты, делитесь знаниями, участвуйте в
          конкурсах и исследуйте миры, созданные вашими сообществами.
        </p>
      </section>
      <section style={{ marginBottom: '2rem' }}>
        <h2>Рекомендации</h2>
        <div style={{ display: 'grid', gap: '1rem' }}>
          {feedItems.map(item => (
            <article key={item.id} style={{
              padding: '1rem',
              background: '#ffffff',
              borderRadius: '0.375rem',
              boxShadow: '0 1px 2px rgba(0,0,0,0.05)',
            }}>
              <h3 style={{ margin: '0 0 0.5rem 0' }}>{item.title}</h3>
              <p style={{ margin: 0 }}>{item.description}</p>
            </article>
          ))}
        </div>
      </section>
    </div>
  );
}