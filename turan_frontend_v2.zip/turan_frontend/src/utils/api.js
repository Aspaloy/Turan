/**
 * Simple helper for making API requests to the FastAPI backend. It exposes
 * get and post methods that return parsed JSON data. The base URL is
 * defined relative to the environment; when running locally the backend
 * should be available on http://127.0.0.1:8000. When deployed on GitHub
 * Pages the CORS policy prevents cross‑domain calls unless you proxy
 * requests. If you deploy the backend elsewhere adjust the baseUrl.
 */
export const api = {
  baseUrl: 'http://127.0.0.1:8000',
  async get(path) {
    const response = await fetch(`${this.baseUrl}${path}`);
    if (!response.ok) {
      throw new Error(`Ошибка сети: ${response.status}`);
    }
    return await response.json();
  },
  async post(path, data) {
    const response = await fetch(`${this.baseUrl}${path}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!response.ok) {
      throw new Error(`Ошибка сети: ${response.status}`);
    }
    return await response.json();
  },
};