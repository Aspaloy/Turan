import React from 'react';
import Index from './pages/Index.jsx';
import Worlds from './pages/Worlds.jsx';
import Stats from './pages/Stats.jsx';
import Profile from './pages/Profile.jsx';
import Navbar from './components/Navbar.jsx';

// App is the top‑level component that implements a very simple router. It
// selects a page component based on the current URL path. This avoids
// introducing an additional dependency like react‑router for this small
// prototype. If you later decide to use a more robust router you can
// replace this logic accordingly.
export default function App() {
  const path = window.location.pathname.replace(/\/+$/, '');
  let PageComponent;
  switch (path) {
    case '':
    case '/Turan':
    case '/Turan/':
    case '/':
      PageComponent = Index;
      break;
    case '/worlds':
    case '/Turan/worlds':
      PageComponent = Worlds;
      break;
    case '/stats':
    case '/Turan/stats':
      PageComponent = Stats;
      break;
    case '/profile':
    case '/Turan/profile':
      PageComponent = Profile;
      break;
    default:
      PageComponent = () => (
        <div style={{ padding: '20px' }}>
          <h1>Страница не найдена</h1>
          <p>К сожалению, такой страницы не существует.</p>
        </div>
      );
  }
  return (
    <div>
      <Navbar />
      <main>
        <PageComponent />
      </main>
    </div>
  );
}